﻿namespace ShopManager
{
    partial class LoginForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtLogin = new TextBox();
            txtPassword = new TextBox();
            btnEnter = new Button();
            btnGoToRegister = new Button();
            SuspendLayout();
            // 
            // txtLogin
            // 
            txtLogin.Location = new Point(12, 51);
            txtLogin.Name = "txtLogin";
            txtLogin.PlaceholderText = "Логин";
            txtLogin.Size = new Size(176, 23);
            txtLogin.TabIndex = 0;
            // 
            // txtPassword
            // 
            txtPassword.Location = new Point(206, 51);
            txtPassword.Name = "txtPassword";
            txtPassword.PasswordChar = '*';
            txtPassword.PlaceholderText = "Пароль";
            txtPassword.Size = new Size(176, 23);
            txtPassword.TabIndex = 1;
            // 
            // btnEnter
            // 
            btnEnter.Font = new Font("Century", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 204);
            btnEnter.Location = new Point(12, 140);
            btnEnter.Name = "btnEnter";
            btnEnter.Size = new Size(176, 56);
            btnEnter.TabIndex = 2;
            btnEnter.Text = "Войти";
            btnEnter.UseVisualStyleBackColor = true;
            btnEnter.Click += btnEnter_Click;
            // 
            // btnGoToRegister
            // 
            btnGoToRegister.Font = new Font("Century", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 204);
            btnGoToRegister.Location = new Point(206, 140);
            btnGoToRegister.Name = "btnGoToRegister";
            btnGoToRegister.Size = new Size(176, 56);
            btnGoToRegister.TabIndex = 3;
            btnGoToRegister.Text = "Регистрация";
            btnGoToRegister.UseVisualStyleBackColor = true;
            btnGoToRegister.Click += btnGoToRegister_Click;
            // 
            // LoginForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnGoToRegister);
            Controls.Add(btnEnter);
            Controls.Add(txtPassword);
            Controls.Add(txtLogin);
            Name = "LoginForm";
            Text = "Авторизация";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtLogin;
        private TextBox txtPassword;
        private Button btnEnter;
        private Button btnGoToRegister;
    }
}
