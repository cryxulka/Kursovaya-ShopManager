﻿using System.Data.SQLite;
using System.IO;

public static class DatabaseHelper
{
    // Имя файла базы данных
    private static string dbName = "shop.db";
    public static string ConnectionString = $"Data Source={dbName};Version=3;";

    public static void InitDatabase()
    {
        if (!File.Exists(dbName))
        {
            SQLiteConnection.CreateFile(dbName);
        }

        using (var connection = new SQLiteConnection(ConnectionString))
        {
            connection.Open();
            // Скрипт создания таблиц
            string sql = @"
                CREATE TABLE IF NOT EXISTS Roles (Id INTEGER PRIMARY KEY AUTOINCREMENT, Name TEXT);
                CREATE TABLE IF NOT EXISTS Users (Id INTEGER PRIMARY KEY AUTOINCREMENT, Login TEXT UNIQUE, Password TEXT, Email TEXT, FullName TEXT, RoleId INTEGER DEFAULT 1);
                CREATE TABLE IF NOT EXISTS Categories (Id INTEGER PRIMARY KEY AUTOINCREMENT, Name TEXT);
                CREATE TABLE IF NOT EXISTS Suppliers (Id INTEGER PRIMARY KEY AUTOINCREMENT, Name TEXT, Phone TEXT, Email TEXT);
                CREATE TABLE IF NOT EXISTS Products (Id INTEGER PRIMARY KEY AUTOINCREMENT, Name TEXT, CategoryId INTEGER, SupplierId INTEGER, Price REAL, Stock INTEGER, Description TEXT);
                CREATE TABLE IF NOT EXISTS Clients (Id INTEGER PRIMARY KEY AUTOINCREMENT, Name TEXT, Email TEXT, Phone TEXT, Address TEXT);
                CREATE TABLE IF NOT EXISTS Sales (Id INTEGER PRIMARY KEY AUTOINCREMENT, ClientId INTEGER, UserId INTEGER, SaleDate TEXT, TotalAmount REAL, PaymentMethod TEXT);
                CREATE TABLE IF NOT EXISTS SaleDetails (Id INTEGER PRIMARY KEY AUTOINCREMENT, SaleId INTEGER, ProductId INTEGER, Quantity INTEGER, TotalSum REAL);
            ";
            using (var cmd = new SQLiteCommand(sql, connection))
            {
                cmd.ExecuteNonQuery();
            }
        }
    }
}