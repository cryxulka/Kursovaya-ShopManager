﻿namespace ShopManager
{
    partial class RegisterForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtPassword = new TextBox();
            txtFIO = new TextBox();
            txtEmail = new TextBox();
            txtLogin = new TextBox();
            btnRegister = new Button();
            btnBack = new Button();
            SuspendLayout();
            // 
            // txtPassword
            // 
            txtPassword.Location = new Point(189, 68);
            txtPassword.Name = "txtPassword";
            txtPassword.PasswordChar = '*';
            txtPassword.PlaceholderText = "Пароль";
            txtPassword.Size = new Size(171, 23);
            txtPassword.TabIndex = 0;
            // 
            // txtFIO
            // 
            txtFIO.Location = new Point(189, 115);
            txtFIO.Name = "txtFIO";
            txtFIO.PlaceholderText = "ФИО";
            txtFIO.Size = new Size(171, 23);
            txtFIO.TabIndex = 1;
            // 
            // txtEmail
            // 
            txtEmail.Location = new Point(12, 115);
            txtEmail.Name = "txtEmail";
            txtEmail.PlaceholderText = "Email";
            txtEmail.Size = new Size(171, 23);
            txtEmail.TabIndex = 2;
            // 
            // txtLogin
            // 
            txtLogin.Location = new Point(12, 68);
            txtLogin.Name = "txtLogin";
            txtLogin.PlaceholderText = "Логин";
            txtLogin.Size = new Size(171, 23);
            txtLogin.TabIndex = 3;
            // 
            // btnRegister
            // 
            btnRegister.Font = new Font("Century", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 204);
            btnRegister.Location = new Point(12, 184);
            btnRegister.Name = "btnRegister";
            btnRegister.Size = new Size(171, 69);
            btnRegister.TabIndex = 4;
            btnRegister.Text = "Зарегистрироваться";
            btnRegister.UseVisualStyleBackColor = true;
            btnRegister.Click += btnRegister_Click;
            // 
            // btnBack
            // 
            btnBack.Font = new Font("Century", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 204);
            btnBack.Location = new Point(189, 184);
            btnBack.Name = "btnBack";
            btnBack.Size = new Size(165, 69);
            btnBack.TabIndex = 5;
            btnBack.Text = "Уже есть аккаунт";
            btnBack.UseVisualStyleBackColor = true;
            btnBack.Click += btnBack_Click;
            // 
            // RegisterForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnBack);
            Controls.Add(btnRegister);
            Controls.Add(txtLogin);
            Controls.Add(txtEmail);
            Controls.Add(txtFIO);
            Controls.Add(txtPassword);
            Name = "RegisterForm";
            Text = "Регистрация";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtPassword;
        private TextBox txtFIO;
        private TextBox txtEmail;
        private TextBox txtLogin;
        private Button btnRegister;
        private Button btnBack;
    }
}