using ShopManager;
using System.Data.SQLite;

namespace ShopManager
{
    public partial class LoginForm : Form
    {
        private void btnGoToRegister_Click(object sender, EventArgs e)
        {
            // Здесь будет код для перехода
            RegisterForm regForm = new RegisterForm();
            regForm.Show();
            this.Hide();
        }

        public LoginForm()
        {
            InitializeComponent();
        }

        private void btnEnter_Click(object sender, EventArgs e)
        {
            using (var connection = new SQLiteConnection(DatabaseHelper.ConnectionString))
            {
                connection.Open();
                // Проверяем, есть ли такой пользователь
                string sql = "SELECT COUNT(*) FROM Users WHERE Login = @login AND Password = @pass";

                using (var cmd = new SQLiteCommand(sql, connection))
                {
                    cmd.Parameters.AddWithValue("@login", txtLogin.Text);
                    cmd.Parameters.AddWithValue("@pass", txtPassword.Text);

                    // ExecuteScalar возвращает одно значение (количество строк)
                    long count = (long)cmd.ExecuteScalar();

                    if (count > 0)
                    {
                        MessageBox.Show("Успешный вход!");
                        // Здесь можно открыть главное окно программы, например:
                        // MainForm main = new MainForm();
                        // main.Show();
                        // this.Hide();
                    }
                    else
                    {
                        MessageBox.Show("Данные неверны, попробуйте снова");
                    }
                }
            }
        }
    }
}