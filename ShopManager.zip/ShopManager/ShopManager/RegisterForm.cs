﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SQLite;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ShopManager
{
    public partial class RegisterForm : Form
    {
        public RegisterForm()
        {
            InitializeComponent();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            LoginForm loginForm = new LoginForm(); // Создаем новое окно логина
            loginForm.Show(); // Показываем его
            this.Close(); // Закрываем окно регистрации
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            try
            {
                using (var connection = new SQLiteConnection(DatabaseHelper.ConnectionString))
                {
                    connection.Open();
                    // Вставляем данные. RoleID пока ставим 1
                    string sql = "INSERT INTO Users (Login, Password, Email, FullName, RoleID) VALUES (@login, @pass, @email, @name, 1)";

                    using (var cmd = new SQLiteCommand(sql, connection))
                    {
                        cmd.Parameters.AddWithValue("@login", txtLogin.Text);
                        cmd.Parameters.AddWithValue("@pass", txtPassword.Text);
                        cmd.Parameters.AddWithValue("@email", txtEmail.Text);
                        cmd.Parameters.AddWithValue("@name", txtFIO.Text);

                        cmd.ExecuteNonQuery();
                    }
                }
                MessageBox.Show("Регистрация успешна!");
                // Возврат на форму входа
                new LoginForm().Show();
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка: " + ex.Message);
            }
        }
    }
}
